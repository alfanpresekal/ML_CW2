function [ topology, bestf1 ] = cross_fold_topo(trainingfc,epoch,x,y)
%Run the 10 cross validation and ouputs the f1 value of the average confusion matrix
    counter             =      0;
    %Initialize local variables
    localF1             =      zeros(1,40);
    %Creates the validationSet & dataSet for each fold
    matrices            =      cross_fold_gathering(x,y);
    %For each fold run the simulation
    for i=1:10
        %Optimize the parameters
        localF1         =      localF1 + topologyFinder( trainingfc, epoch, matrices{2}{i}, matrices{4}{i}, matrices{2}{i}(1:100, :), matrices{4}{i}(1:100) );   
        counter         =      counter + 1;
    end
    %Get the best parameters
    [bestF1, topology]  =      max(localF1);
    bestf1              =      localF1(1,topology);
end

